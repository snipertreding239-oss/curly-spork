<?php
const ADMIN_PASSWORD = 'Sajith2000';
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['success'=>false,'message'=>'POST only']); exit; }
if (!isset($_POST['password']) || !hash_equals(ADMIN_PASSWORD,(string)$_POST['password'])) { http_response_code(403); echo json_encode(['success'=>false,'message'=>'වැරදි Password එකක්.']); exit; }
if (!isset($_FILES['pdf']) || $_FILES['pdf']['error'] !== UPLOAD_ERR_OK) { http_response_code(400); echo json_encode(['success'=>false,'message'=>'PDF file එකක් තෝරන්න.']); exit; }
$f=$_FILES['pdf'];
if ($f['size'] > 25*1024*1024) { http_response_code(413); echo json_encode(['success'=>false,'message'=>'PDF එක 25MB ට වඩා විශාලයි.']); exit; }
$fi=new finfo(FILEINFO_MIME_TYPE);
if ($fi->file($f['tmp_name']) !== 'application/pdf') { http_response_code(400); echo json_encode(['success'=>false,'message'=>'PDF files පමණක් upload කරන්න.']); exit; }
$dir=__DIR__.'/pdfs';
if(!is_dir($dir) && !mkdir($dir,0755,true)){ http_response_code(500); echo json_encode(['success'=>false,'message'=>'pdfs folder එක create කළ නොහැක.']); exit; }
$title=trim($_POST['title'] ?? pathinfo($f['name'],PATHINFO_FILENAME));
$title=preg_replace('/[^\p{L}\p{N}\s._-]/u','',$title);
$title=trim($title) ?: 'PDF';
$base=preg_replace('/[^A-Za-z0-9_-]+/','-', $title);
$base=trim($base,'-_') ?: 'document';
$name=$base.'-'.date('Ymd-His').'-'.bin2hex(random_bytes(3)).'.pdf';
if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$name)){http_response_code(500);echo json_encode(['success'=>false,'message'=>'PDF save කිරීමට නොහැක.']);exit;}
echo json_encode(['success'=>true,'name'=>$name,'title'=>$title],JSON_UNESCAPED_UNICODE);
?>
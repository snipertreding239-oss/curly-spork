<?php
header('Content-Type: application/json; charset=utf-8');
$dir=__DIR__.'/pdfs'; $a=[];
if(is_dir($dir)) foreach(glob($dir.'/*.pdf') as $f){
 $n=basename($f); $t=preg_replace('/\.pdf$/i','',$n);
 $t=preg_replace('/-\d{8}-\d{6}-[a-f0-9]{6}$/i','',$t);
 $a[]=['name'=>$n,'title'=>$t,'url'=>'pdfs/'.rawurlencode($n)];
}
usort($a,function($x,$y){return strcmp($x['name'],$y['name']);});
echo json_encode($a,JSON_UNESCAPED_UNICODE);
?>
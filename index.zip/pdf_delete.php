<?php
const ADMIN_PASSWORD='Sajith2000';
header('Content-Type: application/json; charset=utf-8');
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['success'=>false,'message'=>'POST only']);exit;}
if(!isset($_POST['password'])||!hash_equals(ADMIN_PASSWORD,(string)$_POST['password'])){http_response_code(403);echo json_encode(['success'=>false,'message'=>'වැරදි Password එකක්.']);exit;}
$n=basename($_POST['name']??'');
if($n===''||!preg_match('/\.pdf$/i',$n)){http_response_code(400);echo json_encode(['success'=>false,'message'=>'Invalid PDF']);exit;}
$f=__DIR__.'/pdfs/'.$n;
if(!is_file($f)){http_response_code(404);echo json_encode(['success'=>false,'message'=>'PDF එක හමු නොවීය.']);exit;}
if(!unlink($f)){http_response_code(500);echo json_encode(['success'=>false,'message'=>'PDF delete කිරීමට නොහැක.']);exit;}
echo json_encode(['success'=>true]);
?>